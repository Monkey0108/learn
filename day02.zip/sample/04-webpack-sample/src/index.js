import foo from './foo'

import './style.css'

console.log('fff11')

console.log(foo())
