// gulp 中每一个任务就是一个函数，执行这个任务就是执行这个函数
const task1 = (done) => {
  console.log('task1')
  done()
}

// 所有需要在命令行中直接执行的任务都需要作为导出对象的成员
module.exports = { task1 }
