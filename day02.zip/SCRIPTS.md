# 前端工程化

## 概述

一切以提高效率、降低成本、质量保证为目的的手段或工具都可以称之为「工程化」。

而「前端工程化」是指围绕前端方面解决此类问题的方法，相对于其他技术方向的工程化，前端工程化的特点是「种类繁多」、「方式各异」，但是目标都是一样的：

1. 提高效率
   1. HTML、CSS、JavaScript 语法扩展
   2. 重复工作
   3. 模块化 / 组件化
   4. 发布 / 部署流程
2. 质量保证
   1. 代码风格、格式统一
   2. 代码质量保证

## 基于 Gulp 的工作流

> 案例分析：构建 pages-boilerplate 工作流

按照你的设想搭建项目结构，然后通过编写工作流满足你的这些设想

1. 能够使用扩展语法提高编码效率
2. 能够将页面中的公共部分提取到统一文件维护
3. 能够通过浏览器自动实时预览
4. 能够自动发布到服务端

### 工作流搭建

1. 规划项目结构：核心思路就是将开发阶段的代码和生产阶段的代码分为两份，有工具完成这其中的转化工作。
2. 初始化 package.json，维护项目依赖的工具和模块
3. 安装 Gulp 依赖（Gulp 是一款可以自动化执行你项目中 `gulpfile.js` 中所定义的任务的工具）
4. 项目根目录添加 `gulpfile.js` 文件
5. 更加需求完成不同的任务逻辑

```js
const path = require('path')
const gulp = require('gulp')
const gulpLoadPlugins = require('gulp-load-plugins')
const minimist = require('minimist')
const del = require('del')
const Comb = require('csscomb')
const standard = require('standard')
const browserSync = require('browser-sync')
const autoprefixer = require('autoprefixer')
const cssnano = require('cssnano')

// Put the data used on the page here.
// Use `{{ prop }}` interpolation expressions in pages to get data
const data = {
  menus: [
    {
      name: 'Home',
      icon: 'aperture',
      link: 'index.html'
    },
    {
      name: 'Features',
      link: 'features.html'
    },
    {
      name: 'About',
      link: 'about.html'
    },
    {
      name: 'Contact',
      link: '#',
      children: [
        {
          name: 'Twitter',
          link: 'https://twitter.com/w_zce'
        },
        {
          name: 'About',
          link: 'https://weibo.com/zceme'
        },
        {
          name: 'divider'
        },
        {
          name: 'About',
          link: 'https://github.com/zce'
        }
      ]
    }
  ],
  pkg: require('./package.json'),
  date: new Date()
}

// You can modify the default folder structure here,
// but I don't recommend it.
const config = {
  src: 'src',
  dest: 'dist',
  public: 'public',
  temp: 'temp',
  paths: {
    pages: '**/*.html',
    styles: 'assets/styles/**/*.scss',
    scripts: 'assets/scripts/**/*.js',
    images: 'assets/images/**/*.{jpg,jpeg,png,gif,svg}',
    fonts: 'assets/fonts/**/*.{eot,svg,ttf,woff,woff2}'
  }
}

const $ = gulpLoadPlugins()
const bs = browserSync.create()
const argv = minimist(process.argv.slice(2))
const isProd = process.env.NODE_ENV
  ? process.env.NODE_ENV === 'production'
  : argv.production || argv.prod || false

const clean = () => {
  return del([config.temp, config.dest])
}

const lint = done => {
  const comb = new Comb('zen')
  comb.processPath(config.src)
  const cwd = path.join(__dirname, config.src)
  standard.lintFiles(config.paths.scripts, { cwd, fix: true }, done)
}

const style = () => {
  return gulp.src(config.paths.styles, { cwd: config.src, base: config.src, sourcemaps: !isProd })
    .pipe($.plumber({ errorHandler: $.sass.logError }))
    .pipe($.sass.sync({ outputStyle: 'expanded', precision: 10, includePaths: ['.'] }))
    .pipe($.postcss([autoprefixer()]))
    .pipe(gulp.dest(config.temp, { sourcemaps: '.' }))
    .pipe(bs.reload({ stream: true }))
}

const script = () => {
  return gulp.src(config.paths.scripts, { cwd: config.src, base: config.src, sourcemaps: !isProd })
    .pipe($.plumber())
    .pipe($.babel())
    .pipe(gulp.dest(config.temp, { sourcemaps: '.' }))
    .pipe(bs.reload({ stream: true }))
}

const page = () => {
  return gulp.src(config.paths.pages, { cwd: config.src, base: config.src, ignore: ['{layouts,partials}/**'] })
    .pipe($.plumber())
    .pipe($.swig({ defaults: { cache: false, locals: data } }))
    .pipe(gulp.dest(config.temp))
    // use bs-html-injector instead
    // .pipe(bs.reload({ stream: true }))
}

const useref = () => {
  // https://beautifier.io
  const beautifyOpts = { indent_size: 2, max_preserve_newlines: 1 }
  // https://github.com/mishoo/UglifyJS2#minify-options
  const uglifyOpts = { compress: { drop_console: true } }
  // https://cssnano.co/guides/
  const postcssOpts = [cssnano({ safe: true, autoprefixer: false })]
  // https://github.com/kangax/html-minifier#options-quick-reference
  const htmlminOpts = {
    collapseWhitespace: true,
    minifyCSS: true,
    minifyJS: true,
    processConditionalComments: true,
    removeComments: true,
    removeEmptyAttributes: true,
    removeScriptTypeAttributes: true,
    removeStyleLinkTypeAttributes: true
  }

  return gulp.src(config.paths.pages, { cwd: config.temp, base: config.temp })
    .pipe($.plumber())
    .pipe($.useref({ searchPath: [config.temp, config.src, '.'] }))
    .pipe($.if(/\.js$/, $.if(isProd, $.uglify(uglifyOpts), $.beautify.js(beautifyOpts))))
    .pipe($.if(/\.css$/, $.if(isProd, $.postcss(postcssOpts), $.beautify.css(beautifyOpts))))
    .pipe($.if(/\.html$/, $.if(isProd, $.htmlmin(htmlminOpts), $.beautify.html(beautifyOpts))))
    .pipe(gulp.dest(config.dest))
}

const image = () => {
  return gulp.src(config.paths.images, { cwd: config.src, base: config.src, since: gulp.lastRun(image) })
    .pipe($.plumber())
    .pipe($.if(isProd, $.imagemin()))
    .pipe(gulp.dest(config.dest))
}

const font = () => {
  return gulp.src(config.paths.fonts, { cwd: config.src, base: config.src })
    .pipe($.plumber())
    .pipe($.if(isProd, $.imagemin()))
    .pipe(gulp.dest(config.dest))
}

const extra = () => {
  return gulp.src('**', { cwd: config.public, base: config.public, dot: true })
    .pipe(gulp.dest(config.dest))
}

const measure = () => {
  return gulp.src('**', { cwd: config.dest })
    .pipe($.plumber())
    .pipe($.size({ title: `${isProd ? 'Prodcuction' : 'Development'} mode build`, gzip: true }))
}

const upload = () => {
  return gulp.src('**', { cwd: config.dest })
    .pipe($.plumber())
    .pipe($.ghPages({
      cacheDir: `${config.temp}/publish`,
      branch: argv.branch === undefined ? 'gh-pages' : argv.branch
    }))
}

const devServer = () => {
  gulp.watch(config.paths.styles, { cwd: config.src }, style)
  gulp.watch(config.paths.scripts, { cwd: config.src }, script)
  gulp.watch(config.paths.pages, { cwd: config.src }, page)
  gulp.watch([config.paths.images, config.paths.fonts], { cwd: config.src }, bs.reload)
  gulp.watch('**', { cwd: config.public }, bs.reload)

  bs.init({
    notify: false,
    port: argv.port === undefined ? 2080 : argv.port,
    open: argv.open === undefined ? false : argv.open,
    plugins: [`bs-html-injector?files[]=${config.temp}/*.html`],
    server: {
      baseDir: [config.temp, config.src, config.public],
      routes: { '/node_modules': 'node_modules' }
    }
  })
}

const distServer = () => {
  bs.init({
    notify: false,
    port: argv.port === undefined ? 2080 : argv.port,
    open: argv.open === undefined ? false : argv.open,
    server: config.dest
  })
}

const compile = gulp.parallel(style, script, page)

const serve = gulp.series(compile, devServer)

const build = gulp.series(clean, gulp.parallel(gulp.series(compile, useref), image, font, extra), measure)

const start = gulp.series(build, distServer)

const deploy = gulp.series(build, upload)

module.exports = { clean, lint, compile, serve, build, start, deploy }
```

### 提取到公共模块

由于当前工作流可能在其他项目中复用，为了便于统一维护，可以将工作流配置提取到单个模块中，在不同项目中引用。

## 基于 Webpack 的工作流

> 案例分析：脱离脚手架单独搭建 Vue.js 项目所需工作流

相比于 Gulp，Webpack 实际上只能算得上是模块打包工具，但是由于 Vue.js / React.js 这类项目对工作流的核心需求就是模块打包，所以 Webpack 流行。

### Webpack 基本演练

https://webpack.docschina.org/

### 使用自定义 Webpack 配置 Vue.js 项目所需工作流

```js
const path = require('path')
const webpack = require('webpack')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const VueLoaderPlugin = require('vue-loader/lib/plugin')
const CopyPlugin = require('copy-webpack-plugin')

module.exports = {
  mode: 'development',
  entry: './src/main.js',
  output: {
    filename: 'bundle.js',
    path: path.join(__dirname, 'dist')
  },
  devtool: 'inline-source-map',
  devServer: {
    contentBase: './dist'
  },
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [
          'style-loader',
          'css-loader'
        ]
      },
      {
        test: /\.(png|svg|jpg|gif)$/,
        use: [
          'file-loader'
        ]
      },
      {
        test: /\.vue$/,
        loader: 'vue-loader'
      }
    ]
  },
  plugins: [
    new webpack.DefinePlugin({
      BASE_URL: '""'
    }),
    new CopyPlugin([
      { from: './public' }
    ]),
    new HtmlWebpackPlugin({
      title: 'Hello Vue.js',
      template: './public/index.html'
    }),
    new VueLoaderPlugin()
  ]
}
```

## 其他有用的工具

- Prettier
- Travis CI
- surge