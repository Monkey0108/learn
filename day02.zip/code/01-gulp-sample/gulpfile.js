// 这里是一个会被 Node.js 执行的 js 文件
// 用于定义你希望自动化执行的任务

const task1 = (done) => {
  console.log('task1')
  done() // 表示任务完成
}

const task2 = () => {
  console.log('task2')
}

module.exports = {
  task1,
  task2
}
