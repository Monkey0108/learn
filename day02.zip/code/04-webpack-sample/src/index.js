import hello from './hello'

import './style.css'

import png from './logo.png'

console.log(hello())
console.log(png)
