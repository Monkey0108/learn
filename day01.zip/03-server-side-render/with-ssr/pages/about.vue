<template>
  <div class="container">
    <h1>About</h1>
    <p>this is about page</p>
  </div>
</template>

<script>
export default {}
</script>
