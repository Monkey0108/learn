import React from 'react'
import { connect } from 'react-redux'

const Switch = ({ theme, changeThemeColor, changeThemeBackground }) => {
  return (
    <div>
      <p>
        Background:
        <input
          type="color"
          value={theme.background}
          onChange={e => changeThemeBackground(e.target.value)}
        />
      </p>
      <p>
        Color:
        <input
          type="color"
          value={theme.color}
          onChange={e => changeThemeColor(e.target.value)}
        />
      </p>
    </div>
  )
}

const actions = {
  changeThemeColor: color => ({ type: 'CHANGE_THEME_COLOR', payload: color }),
  changeThemeBackground: color => ({ type: 'CHANGE_THEME_BACKGROUND', payload: color })
}

export default connect(state => ({ theme: state.theme }), actions)(Switch)
