import React from 'react'
import { connect } from 'react-redux'

const Box = ({ theme, children }) => (
  <div style={{
    width: '100px',
    height: '100px',
    border: '1px solid #ccc',
    background: theme.background,
    color: theme.color
  }}>
    {children}
  </div>
)

export default connect(state => ({ theme: state.theme }))(Box)
