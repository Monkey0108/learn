const initialState = {
  theme: {
    background: '#f7f8fb',
    color: '#345'
  }
}

export default (state = initialState, action) => {
  switch (action.type) {
    case 'CHANGE_THEME_COLOR':
      return { ...state, theme: { ...state.theme, color: action.payload } }
    case 'CHANGE_THEME_BACKGROUND':
      return { ...state, theme: { ...state.theme, background: action.payload } }
    default:
      return state
  }
}
