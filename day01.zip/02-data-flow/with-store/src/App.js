import React from 'react'
import Box from './components/Box'
import Switch from './components/Switch'

export default () => (
  <div style={{
    margin: '100px auto',
    maxWidth: '800px'
  }}>
    <Switch/>
    <Box>This is box 1</Box>
  </div>
)
