import React from 'react'

export default ({ theme, children }) => {
  return (
    <div style={{
      width: '100px',
      height: '100px',
      border: '1px solid #ccc',
      background: theme.background,
      color: theme.color
    }}>
      {children}
    </div>
  )
}
