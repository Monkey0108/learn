import React from 'react'

export default ({ theme, onThemeChange }) => (
  <div>
    <p>
      Background:
      <input
        type="color"
        value={theme.background}
        onChange={e => onThemeChange({ ...theme, background: e.target.value })}
      />
    </p>
    <p>
      Color:
      <input
        type="color"
        value={theme.color}
        onChange={e => onThemeChange({ ...theme, color: e.target.value })}
      />
    </p>
  </div>
)
