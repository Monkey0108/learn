import React, { Component } from 'react'
import Box from './components/Box'
import Switch from './components/Switch'

export default class App extends Component {
  constructor (props) {
    super(props)
    this.state = {
      theme: {
        background: '#f7f8fb',
        color: '#345'
      }
    }

    this.handleThemeChange = this.handleThemeChange.bind(this)
  }

  handleThemeChange (value) {
    this.setState({ theme: value })
  }

  render () {
    return (
      <div style={{
        margin: '100px auto',
        maxWidth: '800px'
      }}>
        <Switch theme={this.state.theme} onThemeChange={this.handleThemeChange}/>
        <Box theme={this.state.theme}>This is box 1</Box>
      </div>
    )
  }
}
