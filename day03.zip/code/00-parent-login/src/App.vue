<template>
  <div id="app">
    <Login @login="changeUser"/>
    <hr>
    <Profile :currentUser="currentUser"/>
  </div>
</template>

<script>
import Login from './components/Login.vue'
import Profile from './components/Profile.vue'

export default {
  name: 'app',
  data () {
    return {
      currentUser: null
    }
  },
  components: {
    Login,
    Profile
  },
  methods: {
    changeUser (user) {
      console.log(user)
      this.currentUser = user
    }
  }
}
</script>
