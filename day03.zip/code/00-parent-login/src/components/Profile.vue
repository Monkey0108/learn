<template>
  <h1>{{ currentUser.name }}</h1>
</template>

<script>
export default {
  name: 'Profile',
  props: {
    currentUser: Object
  }
}
</script>
