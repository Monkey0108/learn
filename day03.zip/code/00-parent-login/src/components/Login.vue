<template>
  <form class="form-signin" @submit.prevent="login">
    <img class="mb-4" src="/docs/4.3/assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
    <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
    <label for="inputEmail" class="sr-only">Email address</label>
    <input v-model="username" type="text" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
    <label for="inputPassword" class="sr-only">Password</label>
    <input v-model="password" type="password" id="inputPassword" class="form-control" placeholder="Password" required>
    <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
  </form>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Login',
  data () {
    return {
      username: '',
      password: ''
    }
  },
  methods: {
    login () {
      axios.post('https://jsonplaceholder.uieee.com/tokens', {
        username: this.username,
        password: this.password
      })
      .then(res => {
        const { token } = res.data
        return axios.get('https://jsonplaceholder.uieee.com/users/me', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        })
      })
      .then(res => {
        // console.log(res.data)
        this.$emit('login', res.data)
      })
      .catch(e => {
        console.error(e)
      })


      // const task = () => {
      //   // ..
      // }

      // task()
      //   .then(res => {
      //     console.log('任务执行完了')

      //     return task()
      //   })
      //   .then(res => {
      //     console.log('任务执行完了2')

      //     return task()
      //   })
      //   .then(res => {
      //     console.log('任务执行完了3')
      //   })


      // const res = await task()
      // console.log('任务执行完了')

      // const res = await task()
      // console.log('任务执行完了')

      // const res = await task()
      // console.log('任务执行完了')

      // const res = await task()
      // console.log('任务执行完了')

      // Promise.all([task(), task(), task()]).then((res1, res2, res3) => {

      // })
    }
  }
}
</script>

<style>
.form-signin {
  width: 100%;
  max-width: 330px;
  padding: 15px;
  margin: auto;
}
.form-signin .checkbox {
  font-weight: 400;
}
.form-signin .form-control {
  position: relative;
  box-sizing: border-box;
  height: auto;
  padding: 10px;
  font-size: 16px;
}
.form-signin .form-control:focus {
  z-index: 2;
}
.form-signin input[type="text"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
</style>
