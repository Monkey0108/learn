<template>
  <h1 v-if="currentUser">{{ currentUser.name }}</h1>
</template>

<script>
export default {
  name: 'Profile',
  computed: {
    currentUser () {
      return this.$store.state.currentUser
    }
  }
}
</script>
