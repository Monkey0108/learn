import Vue from 'vue'
import App from './App.vue'
import store from './store'

// 1. 安装 vuex
// 2. 在全局范围使用 vuex插件

// 全局样式文件载入
import 'bootstrap/dist/css/bootstrap.css'

Vue.config.productionTip = false

new Vue({
  store,
  render: h => h(App),
}).$mount('#app')
