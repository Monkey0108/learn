import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    currentUser: null
  },
  mutations: {
    // changeUser
    changeUser (state, payload) {
      // 这里不能有异步代码
      state.currentUser = payload.user
    }
  },
  actions: {
    getCurrentUser ({ commit }, payload) {
      return axios.get('https://jsonplaceholder.uieee.com/users/me', {
        headers: {
          Authorization: `Bearer ${payload.token}`
        }
      }).then(res => {
        commit('changeUser', { user: res.data })
      })
    }
  }
})
