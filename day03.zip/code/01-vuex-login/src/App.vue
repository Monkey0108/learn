<template>
  <div id="app">
    <Login/>
    <hr>
    <Profile/>
  </div>
</template>

<script>
import Login from './components/Login.vue'
import Profile from './components/Profile.vue'

export default {
  name: 'app',
  components: {
    Login,
    Profile
  }
}
</script>
