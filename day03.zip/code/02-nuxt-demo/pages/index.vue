<template>
  <div>
    <h1>{{ msg }}</h1>

    <ul>
      <li v-for="item in categories">
        <nuxt-link :to="{ name: 'detail-id', params: { id: item.id } }">{{ item.name }}</nuxt-link>
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'index',
  data () {
    return  {
      msg: 'hello world',
      categories: []
    }
  },
  created () {
    axios.get('https://locally.uieee.com/categories')
      .then(res => {
        this.categories = res.data
      })
  }
}
</script>
