<!-- /detail/:id -->
<template>
  <h1>{{ $route.params.id }}</h1>
</template>
