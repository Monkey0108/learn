<template>
  <section class="todoapp">
    <header class="header">
      <h1>todos</h1>
      <input v-model="input" @keyup.enter="addTodo" class="new-todo" placeholder="What needs to be done?" autofocus>
    </header>
    <!-- This section should be hidden by default and shown when there are todos -->
    <section class="main">
      <input id="toggle-all" class="toggle-all" type="checkbox">
      <label for="toggle-all">Mark all as complete</label>
      <ul class="todo-list">
        <!-- These are here just to show the structure of the list items -->
        <!-- List items should get the class `editing` when editing and `completed` when marked as completed -->
        <li v-for="todo in shows" :class="{ completed: todo.completed }">
          <div class="view">
            <input @change="toggleTodo(todo)" class="toggle" type="checkbox" :checked="todo.completed">
            <label>{{ todo.text }}</label>
            <button @click="removeTodo(todo)" class="destroy"></button>
          </div>
          <input class="edit" :value="todo.text">
        </li>
      </ul>
    </section>
    <!-- This footer should hidden by default and shown when there are todos -->
    <footer class="footer">
      <!-- This should be `0 items left` by default -->
      <span class="todo-count"><strong>0</strong> item left</span>
      <!-- Remove this if you don't implement routing -->
      <ul class="filters">
        <li>
          <a :class="{ selected: filter === 'all' }" @click="filter = 'all'" href="#/">All</a>
        </li>
        <li>
          <a :class="{ selected: filter === 'active' }" @click="filter = 'active'" href="#/active">Active</a>
        </li>
        <li>
          <a :class="{ selected: filter === 'completed' }" @click="filter = 'completed'" href="#/completed">Completed</a>
        </li>
      </ul>
      <!-- Hidden if no completed items are left ↓ -->
      <button class="clear-completed">Clear completed</button>
    </footer>
  </section>
</template>

<script>
export default {
  name: 'app',
  data () {
    return {
      input: '',
      filter: 'all',
      todos: [
        { text: 'Learning HTML', completed: true },
        { text: 'Learning CSS', completed: true },
        { text: 'Learning JavaScript', completed: false }
      ]
    }
  },
  computed: {
    shows () {
      if (this.filter === 'active') {
        return this.todos.filter(t => !t.completed)
      }
      if (this.filter === 'completed') {
        return this.todos.filter(t => t.completed)
      }
      return this.todos
    }
  },
  methods: {
    addTodo () {
      this.todos.push({ text: this.input.trim(), completed: false })
      this.input = ''
    },
    removeTodo (todo) {
      this.todos.splice(this.todos.indexOf(todo), 1)
    },
    toggleTodo (todo) {
      todo.completed = !todo.completed
    }
  }
}
</script>
