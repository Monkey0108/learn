module.exports = {
  css: [
    // 直接加载一个 Node.js 模块。（在这里它是一个 Sass 文件）
    'bootstrap/dist/css/bootstrap.css'
  ]
}
