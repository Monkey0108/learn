<template>
  <div>
    <h1>this is nuxt app</h1>
    <ul>
      <li v-for="item in categories">
        <nuxt-link :to="{ name: 'categories-id', params: { id: item.id } }">{{ item.name }}</nuxt-link>
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'index',
  data () {
    return {
      categories: []
    }
  },
  created () {
    axios.get('https://locally.now.sh/categories')
      .then(res => {
        this.categories = res.data
      })
  }
}
</script>
