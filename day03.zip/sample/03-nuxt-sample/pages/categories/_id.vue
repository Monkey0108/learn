<template>
  <div>
    <h1>category {{ id }}</h1>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'index',
  data () {
    return {
      id: this.$route.params.id
    }
  }
}
</script>
