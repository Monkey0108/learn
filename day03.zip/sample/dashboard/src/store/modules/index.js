import comments from './comments'
import options from './options'
import posts from './posts'
import terms from './terms'
import users from './users'

export default { comments, options, posts, terms, users }
