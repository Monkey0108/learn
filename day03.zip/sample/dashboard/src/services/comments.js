/**
 * Comments service
 */

import Resource from './resource'

export default new Resource('comments')
