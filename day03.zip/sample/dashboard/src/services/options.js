/**
 * Options service
 */

import Resource from './resource'

export default new Resource('options')
