<template>
  <transition name="fade">
    <router-view class="wrapper"></router-view>
  </transition>
</template>

<script>
export default {
  name: 'app'
}
</script>
