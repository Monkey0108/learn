<template>
  <div>
    <div class="heading">
      <h1 class="title">Export</h1>
    </div>
    <p>Not yet!</p>
  </div>
</template>

<script>
export default {
  name: 'export'
}
</script>
