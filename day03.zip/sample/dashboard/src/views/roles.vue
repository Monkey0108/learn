<template>
  <div>
    <div class="heading">
      <h1 class="title">Roles</h1>
    </div>
    <p>Not yet!</p>
  </div>
</template>

<script>
// REST API权限集成设计 - 坚持很贵 - 博客园
// http://www.cnblogs.com/fangfan/p/4997277.html

export default {
  name: 'roles'
}
</script>
