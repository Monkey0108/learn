<template>
  <div>
    <div class="heading">
      <h1 class="title">Update</h1>
    </div>
    <p>You are so perfectionism, when can you have a summary version?<br>So where is the update?</p>
  </div>
</template>

<script>
export default {
  name: 'update'
}
</script>
