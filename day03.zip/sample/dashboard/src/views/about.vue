<template>
  <div>
    <div class="heading">
      <h1 class="title">About</h1>
    </div>

    <img class="sign" src="https://img.zce.me/sign.png" alt="Wang Lei">
    <ul>
      <li><a href="https://zce.me">https://zce.me</a></li>
      <li><a href="https://github.com/zce">https://github.com/zce</a></li>
    </ul>

    <hr>

    <h3>About WEDN.NET: </h3>
    <p>Let's wait and see!</p>
  </div>
</template>

<script>
export default {
  name: 'about'
}
</script>

<style scoped>
  .sign {
    max-width: 80%;
  }
</style>
