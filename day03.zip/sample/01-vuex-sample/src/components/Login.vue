<template>
  <div class="form-signin">
    <img class="mb-4" src="/docs/4.3/assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
    <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
    <label for="username" class="sr-only">Username</label>
    <input v-model="username" type="text" id="username" class="form-control" placeholder="Username" required autofocus>
    <label for="password" class="sr-only">Password</label>
    <input v-model="password" type="password" id="password" class="form-control" placeholder="Password" required>
    <button @click="handleLogin" class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Login',
  data () {
    return {
      username: '',
      password: ''
    }
  },
  methods: {
    handleLogin () {
      axios.post('https://dashboard-server.now.sh/tokens', {
        username: this.username.trim(),
        password: this.password.trim()
      })
      .then(res => {
        return axios.get('https://dashboard-server.now.sh/users/me', {
          headers: {
            Authorization: `Bearer ${res.data.token}`
          }
        })
      })
      .then(res => {
        console.log(res.data)
      })
    }
  }
}
</script>

<style>
.form-signin {
  width: 100%;
  max-width: 330px;
  padding: 15px;
  margin: auto;
}
.form-signin .checkbox {
  font-weight: 400;
}
.form-signin .form-control {
  position: relative;
  box-sizing: border-box;
  height: auto;
  padding: 10px;
  font-size: 16px;
}
.form-signin .form-control:focus {
  z-index: 2;
}
.form-signin input[type="text"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}
.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}
</style>
