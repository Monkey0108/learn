<template>
  <div class="container">
    <h1>Vuex Sample</h1>
    <hr>
    <Login/>
    Profile
  </div>
</template>

<script>
import Login from './components/Login.vue'

export default {
  name: 'app',
  components: {
    Login
  }
}
</script>
