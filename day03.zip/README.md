# Vue.js 进阶

- Vuex
- Nuxt.js

## Vuex 数据流框架

1. 下定义：Vue.js 框架下的解决数据流管理的一个库
2. 核心解决的问题：多个组件之间共享状态/数据问题

> 案例：登录过后显示用户信息

1. 未使用数据流管理的应用
2. 使用 Vuex 的应用











### TodoMVC 应用

TodoMVC 模板：https://github.com/tastejs/todomvc-app-template


















## 服务端渲染

> 案例：Nuxt.js 示例
